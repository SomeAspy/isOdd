# isOdd
A pypi package I totally didnt make to get the 2 free titan keys promotion
