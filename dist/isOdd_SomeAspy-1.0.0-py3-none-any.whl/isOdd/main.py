def checkOdd(input):
    if (input % 2 !=0):
        return True
    return False